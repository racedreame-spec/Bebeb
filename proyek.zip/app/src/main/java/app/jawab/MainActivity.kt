package app.jawab

import android.Manifest
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

val G1 = Color(0xFF12B886)
val G2 = Color(0xFF4DABF7)
object S { val tick = mutableIntStateOf(0) }
fun fmt(m: Int) = "%02d.%02d".format(m / 60, m % 60)

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("w", ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<Watchdog>(15, TimeUnit.MINUTES).build())
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme(primary = G1) else lightColorScheme(primary = G1)) { App() }
        }
    }
    override fun onResume() { super.onResume(); S.tick.intValue++ }
}

@Composable fun App() {
    var tab by remember { mutableIntStateOf(0) }
    val ic = listOf(Icons.Default.Home, Icons.Default.Person, Icons.Default.Notifications, Icons.Default.CheckCircle)
    val nm = listOf("Beranda", "Kontak", "Jadwal", "Layanan")
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(G1.copy(alpha = .28f), MaterialTheme.colorScheme.background)))) {
        Scaffold(containerColor = Color.Transparent, bottomBar = {
            NavigationBar { nm.forEachIndexed { i, t -> NavigationBarItem(tab == i, { tab = i }, { Icon(ic[i], null) }, label = { Text(t) }) } }
        }) { p -> Box(Modifier.padding(p)) { Crossfade(tab, label = "tab") { when (it) { 0 -> Home(); 1 -> Contacts(); 2 -> Schedule(); else -> Services() } } } }
    }
}

@Composable fun Home() {
    val c = LocalContext.current
    var on by remember { mutableStateOf(P.on(c)) }
    val col by animateColorAsState(if (on) G1 else Color(0xFF9AA8A1), label = "c")
    val sc by rememberInfiniteTransition(label = "t").animateFloat(1f, 1.8f, infiniteRepeatable(tween(2200, easing = LinearEasing)), label = "s")
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text("Jawab Otomatis", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = G1)
        Text("Panggilan WhatsApp dari kontak pilihan")
        Spacer(Modifier.height(40.dp))
        Box(Modifier.size(270.dp), contentAlignment = Alignment.Center) {
            if (on) Box(Modifier.size(150.dp).scale(sc).alpha(2f - sc).border(2.dp, G1, CircleShape))
            Box(Modifier.size(150.dp).clip(CircleShape).background(Brush.linearGradient(listOf(col, if (on) G2 else col)))
                .clickable { on = !on; P.setOn(c, on); if (on) Watchdog.fix(c) }, contentAlignment = Alignment.Center) {
                Text(if (on) "ON" else "OFF", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
            }
        }
        Text(if (on) "Aktif" else "Nonaktif", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = col)
        Text("${P.contacts(c).count { it.second }} kontak · ${fmt(P.int(c, "s", 480))}–${fmt(P.int(c, "e", 1260))}")
    }
}

@Composable fun Contacts() {
    val c = LocalContext.current
    val list = remember { mutableStateListOf<Pair<String, Boolean>>().apply { addAll(P.contacts(c)) } }
    var nm by remember { mutableStateOf("") }
    fun save() = P.saveContacts(c, list.toList())
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Kontak terpilih", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Tulis nama persis seperti tampil di WhatsApp")
        LazyColumn(Modifier.weight(1f).padding(vertical = 8.dp)) {
            itemsIndexed(list) { i, p ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), shape = RoundedCornerShape(20.dp)) {
                    Row(Modifier.padding(start = 16.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(p.first, Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                        Switch(p.second, { list[i] = p.copy(second = it); save() })
                        IconButton({ list.removeAt(i); save() }) { Icon(Icons.Default.Delete, null) }
                    }
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(nm, { nm = it }, Modifier.weight(1f), singleLine = true, label = { Text("Nama kontak") })
            Button({ if (nm.isNotBlank()) { list.add(nm.trim() to true); save(); nm = "" } }) { Text("Tambah") }
        }
    }
}

@Composable fun Stepper(t: String, v: String, minus: () -> Unit, plus: () -> Unit) =
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(t, Modifier.weight(1f))
        FilledTonalIconButton(minus) { Text("−", fontSize = 22.sp) }
        Text(v, Modifier.widthIn(min = 80.dp), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold)
        FilledTonalIconButton(plus) { Text("+", fontSize = 22.sp) }
    }

@Composable fun Schedule() {
    val c = LocalContext.current
    var days by remember { mutableStateOf(P.days(c)) }
    var s by remember { mutableIntStateOf(P.int(c, "s", 480)) }
    var e by remember { mutableIntStateOf(P.int(c, "e", 1260)) }
    var dl by remember { mutableIntStateOf(P.int(c, "dl", 60)) }
    var mx by remember { mutableIntStateOf(P.int(c, "mx", 3)) }
    var un by remember { mutableStateOf(P.unlock(c)) }
    fun setDays(x: Set<Int>) { days = x; P.saveDays(c, x) }
    fun pick(v: Int, f: (Int) -> Unit) = TimePickerDialog(c, { _, h, m -> f(h * 60 + m) }, v / 60, v % 60, true).show()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Jadwal", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            TextButton({ setDays(setOf(0, 1, 2, 3, 4)) }) { Text("Hari kerja") }
            TextButton({ setDays((0..6).toSet()) }) { Text("Setiap hari") }
            TextButton({ setDays(setOf(5, 6)) }) { Text("Akhir pekan") }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf("Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min").forEachIndexed { i, d ->
                val on = i in days
                Box(Modifier.clip(RoundedCornerShape(18.dp)).background(if (on) G1 else MaterialTheme.colorScheme.surfaceVariant)
                    .clickable { setDays(if (on) days - i else days + i) }.padding(horizontal = 22.dp, vertical = 16.dp)) {
                    Text(d, fontWeight = FontWeight.SemiBold, color = if (on) Color.White else MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton({ pick(s) { s = it; P.putInt(c, "s", it) } }, Modifier.weight(1f)) { Text("Mulai ${fmt(s)}") }
            OutlinedButton({ pick(e) { e = it; P.putInt(c, "e", it) } }, Modifier.weight(1f)) { Text("Selesai ${fmt(e)}") }
        }
        Stepper("Jeda panggil ulang", "$dl dtk", { dl = (dl - 15).coerceAtLeast(15); P.putInt(c, "dl", dl) }, { dl = (dl + 15).coerceAtMost(300); P.putInt(c, "dl", dl) })
        Stepper("Maksimal percobaan", "$mx×", { mx = (mx - 1).coerceAtLeast(1); P.putInt(c, "mx", mx) }, { mx = (mx + 1).coerceAtMost(10); P.putInt(c, "mx", mx) })
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Geser buka kunci otomatis", Modifier.weight(1f)); Switch(un, { un = it; P.setUnlock(c, it) })
        }
    }
}

class Item(val t: String, val ok: Boolean, val go: () -> Unit)

@Composable fun Services() {
    val c = LocalContext.current
    val tk = S.tick.intValue
    val pm = c.getSystemService(PowerManager::class.java)
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { S.tick.intValue++ }
    val pkg = Uri.parse("package:" + c.packageName)
    val items = listOf(
        Item("Akses notifikasi", Watchdog.listenerOk(c)) { c.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) },
        Item("Layanan aksesibilitas", Watchdog.accOk(c)) { c.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
        Item("Tampil di atas aplikasi lain", Settings.canDrawOverlays(c)) { c.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkg)) },
        Item("Tanpa pembatasan baterai", pm.isIgnoringBatteryOptimizations(c.packageName)) { c.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkg)) },
        Item("Izin baca kontak", ContextCompat.checkSelfPermission(c, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) { perm.launch(Manifest.permission.READ_CONTACTS) }
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Kesehatan layanan", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        items.forEach {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(12.dp).clip(CircleShape).background(if (it.ok) G1 else Color(0xFFF0A020)))
                    Text(it.t, Modifier.weight(1f).padding(start = 12.dp), fontWeight = FontWeight.SemiBold)
                    if (!it.ok) FilledTonalButton(it.go) { Text("Atur") } else Text("Sehat", color = G1)
                }
            }
        }
        Button({ Watchdog.fix(c); S.tick.intValue++ }, Modifier.fillMaxWidth()) { Text("Perbaiki otomatis") }
        Text("Catatan terakhir", fontWeight = FontWeight.Bold)
        Text(P.logs(c).ifBlank { "Belum ada catatan" }, fontSize = 12.sp)
    }
}
