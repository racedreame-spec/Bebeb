package app.jawab

import android.content.Context
import java.text.SimpleDateFormat
import java.util.*

object P {
    private fun sp(c: Context) = c.getSharedPreferences("p", 0)
    fun on(c: Context) = sp(c).getBoolean("on", false)
    fun setOn(c: Context, v: Boolean) = sp(c).edit().putBoolean("on", v).apply()
    fun unlock(c: Context) = sp(c).getBoolean("u", true)
    fun setUnlock(c: Context, v: Boolean) = sp(c).edit().putBoolean("u", v).apply()
    fun int(c: Context, k: String, d: Int) = sp(c).getInt(k, d)
    fun putInt(c: Context, k: String, v: Int) = sp(c).edit().putInt(k, v).apply()
    fun contacts(c: Context): List<Pair<String, Boolean>> =
        sp(c).getString("ct", "")!!.split("|").filter { it.contains("~") }
            .map { it.substringBeforeLast("~") to (it.substringAfterLast("~") == "1") }
    fun saveContacts(c: Context, l: List<Pair<String, Boolean>>) = sp(c).edit().putString("ct",
        l.joinToString("|") { it.first.replace("|", "").replace("~", "") + "~" + (if (it.second) "1" else "0") }).apply()
    fun days(c: Context): Set<Int> = sp(c).getString("d", "0,1,2,3,4")!!.split(",").mapNotNull { it.toIntOrNull() }.toSet()
    fun saveDays(c: Context, s: Set<Int>) = sp(c).edit().putString("d", s.joinToString(",")).apply()
    fun inSchedule(c: Context): Boolean {
        val k = Calendar.getInstance()
        if (((k.get(Calendar.DAY_OF_WEEK) + 5) % 7) !in days(c)) return false
        val m = k.get(Calendar.HOUR_OF_DAY) * 60 + k.get(Calendar.MINUTE)
        val s = int(c, "s", 480); val e = int(c, "e", 1260)
        return if (s <= e) m in s until e else (m >= s || m < e)
    }
    fun log(c: Context, t: String) {
        val now = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date()) + " " + t
        val old = sp(c).getString("log", "")!!.split("\n").filter { it.isNotBlank() }
        sp(c).edit().putString("log", (listOf(now) + old).take(15).joinToString("\n")).apply()
    }
    fun logs(c: Context): String = sp(c).getString("log", "")!!
}
