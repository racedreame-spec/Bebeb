package app.jawab

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.ContactsContract
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import androidx.core.app.NotificationManagerCompat
import androidx.work.Worker
import androidx.work.WorkerParameters

class CallListener : NotificationListenerService() {
    private val h = Handler(Looper.getMainLooper())
    private val ans = HashMap<String, Long>()
    private val tries = HashMap<String, Int>()
    private val answerRx = Regex("(?i)answer|jawab|terima|accept")

    private fun ok(t: String) = P.contacts(this).any { it.second && it.first.equals(t.trim(), true) }

    private val declineRx = Regex("(?i)decline|tolak|reject|hang|akhiri|end call|tutup|message|pesan|balas|reply")
    private fun isCall(n: Notification) = n.category == Notification.CATEGORY_CALL || n.fullScreenIntent != null

    override fun onNotificationPosted(s: StatusBarNotification) {
        if (!s.packageName.contains("whatsapp") || !P.on(this)) return
        val n = s.notification
        val title = n.extras.getString(Notification.EXTRA_TITLE) ?: return
        val txt = n.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        if (!ok(title)) return
        if (isCall(n) || Regex("(?i)call|panggilan").containsMatchIn(txt))
            P.log(this, "Notif: $title | ${n.category} | fs=${n.fullScreenIntent != null} | ${n.actions?.joinToString("/") { it.title } ?: "-"} | $txt".take(160))
        if (Regex("(?i)missed|tak terjawab|tidak terjawab").containsMatchIn(txt)) {
            P.log(this, "Tak terjawab: $title"); redial(title, s.packageName); return
        }
        if (!isCall(n)) return
        val acts = n.actions?.toList() ?: emptyList()
        val a = acts.firstOrNull { answerRx.containsMatchIn(it.title) }
            ?: if (n.fullScreenIntent != null) acts.firstOrNull { !declineRx.containsMatchIn(it.title) } else null
        if (a == null && n.fullScreenIntent == null) return
        if (System.currentTimeMillis() - (ans[title] ?: 0L) < 10000) return
        if (!P.inSchedule(this)) { P.log(this, "Di luar jadwal: $title"); return }
        @Suppress("DEPRECATION")
        (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(
            PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP, "jawab:w").acquire(5000)
        val go = Runnable {
            var done = false
            if (a != null) try { a.actionIntent.send(); done = true } catch (e: Exception) { P.log(this, "Aksi jawab gagal: ${e.javaClass.simpleName}") }
            ans[title] = System.currentTimeMillis()
            P.log(this, "Coba jawab: $title" + if (done) "" else " (lewat layar)")
            AnswerService.pend = System.currentTimeMillis()
            if (!done) AnswerService.i?.answerScreen()
            h.postDelayed({ verify(title, s.packageName, n) }, 2500)
        }
        val sv = AnswerService.i
        if (P.unlock(this) && sv != null) { sv.swipeUp(); h.postDelayed(go, 900) } else go.run()
    }

    private fun verify(title: String, pkg: String, n: Notification) {
        val still = try {
            activeNotifications.any { it.packageName == pkg && it.notification.fullScreenIntent != null && it.notification.extras.getString(Notification.EXTRA_TITLE) == title }
        } catch (e: Exception) { false }
        if (!still) return
        P.log(this, "Masih berdering, coba lewat layar: $title")
        try { n.fullScreenIntent?.send() } catch (e: Exception) {}
        h.postDelayed({ AnswerService.i?.answerScreen() }, 700)
    }

    override fun onNotificationRemoved(s: StatusBarNotification) {
        if (!s.packageName.contains("whatsapp") || !isCall(s.notification)) return
        val t = s.notification.extras.getString(Notification.EXTRA_TITLE) ?: return
        val st = ans[t] ?: return
        if (System.currentTimeMillis() - st < 6000) { P.log(this, "Putus cepat: $t"); redial(t, s.packageName) } else tries.remove(t)
    }

    private fun redial(name: String, pkg: String) {
        val n = (tries[name] ?: 0) + 1
        if (n > P.int(this, "mx", 3)) { tries.remove(name); return }
        tries[name] = n
        h.postDelayed({ if (P.on(this) && P.inSchedule(this)) call(name, pkg) }, P.int(this, "dl", 60) * 1000L)
    }

    private fun call(name: String, pkg: String) {
        val busy = try { activeNotifications.any { it.packageName.contains("whatsapp") && (it.notification.category == Notification.CATEGORY_CALL || (it.notification.flags and Notification.FLAG_ONGOING_EVENT != 0 && it.notification.extras.getString(Notification.EXTRA_TITLE) == name)) } } catch (e: Exception) { false }
        if (busy) { P.log(this, "Lewati panggil ulang: sedang ada panggilan"); return }
        val mime = "vnd.android.cursor.item/vnd.com.whatsapp.voip.call"
        try {
            contentResolver.query(ContactsContract.Data.CONTENT_URI, arrayOf(ContactsContract.Data._ID),
                "${ContactsContract.Data.MIMETYPE}=? AND ${ContactsContract.Data.DISPLAY_NAME}=?", arrayOf(mime, name), null)?.use {
                if (it.moveToFirst()) {
                    AnswerService.callMode = true
                    startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse("content://com.android.contacts/data/${it.getLong(0)}"), mime)
                        .setPackage(pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    P.log(this, "Panggil ulang ke $name")
                } else P.log(this, "Kontak $name tidak ditemukan di buku kontak")
            }
        } catch (e: Exception) { P.log(this, "Panggil ulang gagal: ${e.message}") }
    }
}

class AnswerService : AccessibilityService() {
    companion object { var i: AnswerService? = null; var callMode = false; var pend = 0L; var last = 0L }
    private val ansRx = Regex("(?i)answer|jawab|terima|accept|angkat")
    override fun onServiceConnected() { i = this }
    override fun onUnbind(intent: Intent?): Boolean { i = null; return super.onUnbind(intent) }
    override fun onInterrupt() {}
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e?.packageName?.contains("whatsapp") != true) return
        val now = System.currentTimeMillis()
        if (callMode && click(Regex("(?i)^(panggil|call|voice call|panggilan suara)$"))) callMode = false
        if (now - pend < 15000 && now - last > 1200) { last = now; if (press(rootInActiveWindow, false)) pend = 0 }
    }
    fun answerScreen() { pend = System.currentTimeMillis(); press(rootInActiveWindow, true) }
    fun press(root: AccessibilityNodeInfo?, blind: Boolean): Boolean {
        val n = root?.let { find(it) }
        if (n != null) {
            var p: AccessibilityNodeInfo? = n
            while (p != null && !p.isClickable) p = p.parent
            if (p != null && p.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            val r = Rect(); n.getBoundsInScreen(r)
            swipe(r.exactCenterX(), r.exactCenterY(), r.exactCenterX(), (r.exactCenterY() - 700f).coerceAtLeast(60f))
            return true
        }
        if (blind) { val m = resources.displayMetrics; swipe(m.widthPixels / 2f, m.heightPixels * 0.88f, m.widthPixels / 2f, m.heightPixels * 0.4f) }
        return false
    }
    private fun find(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val t = (n.text ?: n.contentDescription)?.toString()?.trim() ?: ""
        if (t.length in 1..40 && ansRx.containsMatchIn(t)) return n
        for (k in 0 until n.childCount) { val c = n.getChild(k) ?: continue; val r = find(c); if (r != null) return r }
        return null
    }
    fun click(rx: Regex): Boolean = rootInActiveWindow?.let { walk(it, rx) } ?: false
    private fun walk(n: AccessibilityNodeInfo, rx: Regex): Boolean {
        val t = (n.text ?: n.contentDescription)?.toString()?.trim() ?: ""
        if (t.isNotEmpty() && rx.matches(t)) {
            var p: AccessibilityNodeInfo? = n
            while (p != null && !p.isClickable) p = p.parent
            if (p != null) { p.performAction(AccessibilityNodeInfo.ACTION_CLICK); return true }
        }
        for (k in 0 until n.childCount) { val c = n.getChild(k) ?: continue; if (walk(c, rx)) return true }
        return false
    }
    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float) {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 350)).build(), null, null)
    }
    fun swipeUp() { val m = resources.displayMetrics; swipe(m.widthPixels / 2f, m.heightPixels * 0.85f, m.widthPixels / 2f, m.heightPixels * 0.15f) }
}

class Watchdog(c: Context, p: WorkerParameters) : Worker(c, p) {
    override fun doWork(): Result { fix(applicationContext); return Result.success() }
    companion object {
        fun listenerOk(c: Context) = NotificationManagerCompat.getEnabledListenerPackages(c).contains(c.packageName)
        fun accOk(c: Context) = (Settings.Secure.getString(c.contentResolver, "enabled_accessibility_services") ?: "").contains(c.packageName + "/")
        fun fix(c: Context) {
            if (!P.on(c)) return
            var msg = ""
            if (!listenerOk(c)) msg += "Akses notifikasi mati. "
            else try { NotificationListenerService.requestRebind(ComponentName(c, CallListener::class.java)) } catch (e: Exception) {}
            if (!accOk(c)) {
                try {
                    val cr = c.contentResolver
                    val cur = Settings.Secure.getString(cr, "enabled_accessibility_services") ?: ""
                    val me = c.packageName + "/" + AnswerService::class.java.name
                    Settings.Secure.putString(cr, "enabled_accessibility_services", if (cur.isBlank()) me else "$cur:$me")
                    Settings.Secure.putInt(cr, "accessibility_enabled", 1)
                    P.log(c, "Aksesibilitas dinyalakan ulang")
                } catch (e: Exception) { msg += "Aksesibilitas mati. " }
            }
            if (msg.isEmpty()) return
            val nm = c.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("w", "Peringatan layanan", NotificationManager.IMPORTANCE_HIGH))
            val pi = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            nm.notify(1, Notification.Builder(c, "w").setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle("Jawab Otomatis").setContentText(msg + "Ketuk untuk memperbaiki")
                .setContentIntent(pi).setAutoCancel(true).build())
        }
    }
}
