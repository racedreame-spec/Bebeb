package com.radar.kapal

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.View
import android.widget.*
import kotlin.math.*

fun vendorName(id: Int): String = when (id) {
    0x004C -> "Apple"
    0x0075 -> "Samsung"
    0x0006 -> "Microsoft"
    0x00E0 -> "Google"
    0x038F -> "Xiaomi"
    0x027D -> "Huawei"
    0x0087 -> "Garmin"
    0x0157 -> "Huami/Amazfit"
    else -> "ID 0x" + Integer.toHexString(id).uppercase()
}

class Dev(val id: String, var name: String, val wifi: Boolean) {
    var rssi = 0.0
    var seen = 0L
    var ts = 0L
    var tx1m = if (wifi) -40.0 else -59.0
    var base = 2.5
    var vendor = ""
    var freq = 0
    var caps = ""
    var conn = false
    val first = System.currentTimeMillis()
    val win = ArrayList<Double>()
    val hist = ArrayList<Float>()
    val bsum = DoubleArray(12)
    val bcnt = IntArray(12)
    val fixedAngle = ((id.hashCode() and 0x7fffffff) % 360).toFloat()

    fun push(r: Int, head: Float) {
        rssi = if (rssi == 0.0) r.toDouble() else rssi * 0.7 + r * 0.3
        win.add(r.toDouble()); if (win.size > 10) win.removeAt(0)
        seen = System.currentTimeMillis()
        val b = (head / 30).toInt().coerceIn(0, 11)
        bsum[b] = bsum[b] + r; bcnt[b]++
    }

    fun std(): Double {
        if (win.size < 5) return 0.0
        val m = win.average()
        return sqrt(win.sumOf { (it - m) * (it - m) } / win.size)
    }

    fun dist(n: Double) = 10.0.pow((tx1m - rssi) / (10 * n))

    fun angle(): Float {
        var best = -1
        var bv = -999.0
        for (i in 0..11) if (bcnt[i] >= 3) {
            val v = bsum[i] / bcnt[i]
            if (v > bv) { bv = v; best = i }
        }
        return if (best >= 0 && bcnt.sum() >= 24) best * 30f + 15f else fixedAngle
    }

    fun label() = name.ifEmpty { id }
}

class MainActivity : Activity(), SensorEventListener {
    private val devs = HashMap<String, Dev>()
    private var heading = 0f
    private var acc = 0
    private var field = 0f
    private var sn = 0.0
    private var cs = 1.0
    private var headUp = true
    private var sens = 3
    private var nExp = 2.5
    private var ri = 2
    private var alarm = true
    private val ranges = floatArrayOf(5f, 10f, 20f, 50f)
    private var tracked: Dev? = null
    private var cur = 0
    private var ticks = 0
    private var wasMotion = false
    private val h = Handler(Looper.getMainLooper())
    private val sm by lazy { getSystemService(SensorManager::class.java) }
    private val wm by lazy { applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager }

    private lateinit var radar: RadarView
    private lateinit var alertTv: TextView
    private lateinit var infoTv: TextView
    private lateinit var listBox: LinearLayout
    private lateinit var calTv: TextView
    private lateinit var trName: TextView
    private lateinit var trDist: TextView
    private lateinit var trHot: TextView
    private lateinit var trInfo: TextView
    private lateinit var chart: ChartView
    private lateinit var trDesc: TextView
    private lateinit var screens: List<View>

    private val green = 0xFF3DDC84.toInt()
    private val txt = 0xFFD4F5E1.toInt()
    private val dim = 0xFF7FBF9C.toInt()
    private val bg = 0xFF0A130F.toInt()

    private val cb = object : ScanCallback() {
        override fun onScanResult(t: Int, r: ScanResult) {
            val id = r.device.address
            val d = devs.getOrPut(id) { Dev(id, "", false) }
            val nm = try { r.device.name } catch (e: SecurityException) { null } ?: r.scanRecord?.deviceName
            if (!nm.isNullOrEmpty()) d.name = nm
            if (d.seen == 0L && r.txPower != 127) d.tx1m = r.txPower - 41.0
            d.conn = r.isConnectable
            r.scanRecord?.manufacturerSpecificData?.let { m -> if (m.size() > 0) d.vendor = vendorName(m.keyAt(0)) }
            d.push(r.rssi, heading)
        }
    }

    private fun tv(t: String, sz: Float = 15f, c: Int = txt) = TextView(this).apply {
        text = t; textSize = sz; setTextColor(c); setPadding(28, 14, 28, 14)
    }

    private fun btn(t: String, f: (Button) -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setTextColor(txt); setBackgroundColor(0xFF16352A.toInt())
        setOnClickListener { f(this) }
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
    private fun fmt(x: Double) = String.format("%.1f", x)
    private fun accText() = when (acc) { 3 -> "tinggi"; 2 -> "sedang"; 1 -> "rendah"; else -> "tidak andal" }
    private fun modeText() = "Mode: " + if (headUp) "depan di atas" else "utara di atas"
    private fun rangeText() = "Skala: ${ranges[ri].roundToInt()} m"
    private fun alarmText() = "Alarm gerakan: " + if (alarm) "aktif" else "mati"
    private fun nText() = "Eksponen lingkungan n: $nExp"

    private fun bandText(d: Dev): String {
        val f = d.freq
        if (f == 0) return "WiFi"
        val ch = when {
            f in 2412..2483 -> (f - 2407) / 5
            f == 2484 -> 14
            f in 5000..5900 -> (f - 5000) / 5
            else -> (f - 5950) / 5
        }
        val band = if (f < 3000) "2,4 GHz" else if (f < 5900) "5 GHz" else "6 GHz"
        return "$band, kanal $ch"
    }

    private fun info(d: Dev, mo: Boolean): String {
        val now = System.currentTimeMillis()
        val a = d.angle()
        val dirs = arrayOf("utara", "timur laut", "timur", "tenggara", "selatan", "barat daya", "barat", "barat laut")
        val q = if (d.rssi > -55) "kuat" else if (d.rssi > -70) "sedang" else "lemah"
        val sb = StringBuilder("KETERANGAN OBJEK\n")
        sb.append("Jenis: ").append(if (d.wifi) "Jaringan WiFi" else "Perangkat Bluetooth LE").append('\n')
        sb.append("Nama: ").append(d.label()).append('\n')
        sb.append(if (d.wifi) "BSSID: " else "Alamat: ").append(d.id).append('\n')
        if (d.wifi) {
            val c = d.caps
            val sec = if (c.contains("WPA3") || c.contains("SAE")) "WPA3" else if (c.contains("WPA2")) "WPA2" else if (c.contains("WPA")) "WPA" else if (c.contains("WEP")) "WEP" else "Terbuka"
            sb.append("Pita: ").append(bandText(d)).append('\n')
            sb.append("Keamanan: ").append(sec).append('\n')
        } else {
            if (d.vendor.isNotEmpty()) sb.append("Pabrikan: ").append(d.vendor).append('\n')
            sb.append("Dapat tersambung: ").append(if (d.conn) "ya" else "tidak").append('\n')
        }
        sb.append("Sinyal: ${d.rssi.roundToInt()} dBm ($q)\n")
        sb.append("Jarak: ± ${fmt(d.dist(nExp))} m\n")
        sb.append("Arah perkiraan: ${a.roundToInt()}° ${dirs[((a + 22.5f) / 45f).toInt() % 8]}")
        sb.append(if (d.bcnt.sum() >= 24) " (dari pindai arah)\n" else " (belum akurat, putar badan pelan)\n")
        sb.append("Status: ").append(if (mo) "ada gerakan di dekatnya" else "tidak ada gerakan").append('\n')
        sb.append("Terlihat sejak ${(now - d.first) / 1000} detik lalu, terakhir ${(now - d.seen) / 1000} detik lalu")
        return sb.toString()
    }

    private fun show(i: Int) {
        cur = i
        screens.forEachIndexed { k, v -> v.visibility = if (k == i) View.VISIBLE else View.GONE }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = bg
        radar = RadarView(this)
        radar.onPick = { d -> tracked = d; show(4) }
        alertTv = tv("", 15f, 0xFFFF9A9A.toInt())
        infoTv = tv("", 13f, 0xFF9FE8BD.toInt())
        val s0 = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(radar, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(alertTv); addView(infoTv)
        }
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val s1 = ScrollView(this).apply { addView(listBox) }
        calTv = tv("", 15f)
        val s2 = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(tv("Kalibrasi kompas", 20f, green))
            addView(tv("Gerakkan HP membentuk angka 8 sampai akurasi tinggi. Jauhi logam dan magnet.", 14f, dim))
            addView(calTv)
            addView(btn("Kalibrasi baseline gerakan (ruangan kosong)") {
                devs.values.forEach { d -> d.base = max(1.0, d.std()) }
                toast("Baseline gerakan disimpan")
            })
        }
        val s3 = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(tv("Pengaturan", 20f, green))
            addView(btn(modeText()) { headUp = !headUp; it.text = modeText() })
            addView(btn(rangeText()) { ri = (ri + 1) % ranges.size; it.text = rangeText() })
            addView(btn(alarmText()) { alarm = !alarm; it.text = alarmText() })
            addView(btn(nText()) { nExp = if (nExp >= 4.0) 2.0 else nExp + 0.5; it.text = nText() })
            addView(tv("Sensitivitas gerakan (1-5)", 14f, dim))
            addView(SeekBar(this@MainActivity).apply {
                max = 4; progress = sens - 1
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { sens = p + 1 }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            })
            addView(tv("Jarak dan arah adalah perkiraan dari kekuatan sinyal (RSSI). Akurasi dapat berubah menurut ruangan dan perangkat.", 12f, dim))
        }
        trName = tv("", 18f, green)
        trDist = tv("", 44f).apply { gravity = Gravity.CENTER }
        trHot = tv("", 15f, 0xFFF2C94C.toInt()).apply { gravity = Gravity.CENTER }
        chart = ChartView(this)
        trInfo = tv("", 13f, 0xFF9FE8BD.toInt())
        trDesc = tv("", 14f, txt)
        val s4col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(trName); addView(trDist); addView(trHot)
            addView(chart, LinearLayout.LayoutParams(-1, 360))
            addView(trInfo); addView(trDesc)
            addView(btn("Kalibrasi 1 m (taruh perangkat 1 m dari HP)") {
                tracked?.let { d -> d.tx1m = d.rssi }
                toast("RSSI 1 m disimpan")
            })
            addView(btn("Kembali") { show(1) })
        }
        val s4 = ScrollView(this).apply { addView(s4col) }
        screens = listOf(s0, s1, s2, s3, s4)
        val content = FrameLayout(this).apply { screens.forEach { addView(it) } }
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            listOf("Radar", "Perangkat", "Kalibrasi", "Atur").forEachIndexed { i, t ->
                addView(btn(t) { show(i) }, LinearLayout.LayoutParams(0, -2, 1f))
            }
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(nav)
        }
        setContentView(root)
        show(0)

        val need = if (Build.VERSION.SDK_INT >= 31)
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (need.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) startScans()
        else requestPermissions(need, 1)
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        startScans()
    }

    private fun startScans() {
        try {
            val bm = getSystemService(BluetoothManager::class.java)
            bm.adapter?.bluetoothLeScanner?.startScan(null, ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(), cb)
        } catch (e: Exception) {
            toast("Bluetooth tidak dapat dipindai: izin atau Bluetooth belum aktif")
        }
    }

    private fun readWifi() {
        try {
            wm.scanResults.forEach { r ->
                val d = devs.getOrPut(r.BSSID) { Dev(r.BSSID, "", true) }
                d.name = if (r.SSID.isNullOrEmpty()) r.BSSID else r.SSID
                d.freq = r.frequency
                d.caps = r.capabilities
                if (r.timestamp != d.ts) { d.ts = r.timestamp; d.push(r.level, heading) }
            }
        } catch (e: SecurityException) {
        }
    }

    private fun vib() {
        try {
            getSystemService(Vibrator::class.java).vibrate(VibrationEffect.createOneShot(300, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (e: Exception) {
        }
    }

    private val loop = object : Runnable {
        override fun run() { tick(); h.postDelayed(this, 1000) }
    }

    private fun tick() {
        ticks++
        if (ticks % 5 == 0) readWifi()
        if (ticks % 30 == 1) try { wm.startScan() } catch (e: Exception) { }
        val now = System.currentTimeMillis()
        val live = devs.values.filter { now - it.seen < (if (it.wifi) 120000L else 15000L) }
        live.forEach { it.hist.add(it.dist(nExp).toFloat()); if (it.hist.size > 60) it.hist.removeAt(0) }
        val mo = live.filter { it.std() > it.base * (1.0 + (6 - sens) * 0.4) }

        radar.pts = live.map { P(it.angle(), it.dist(nExp).toFloat(), it.wifi, it in mo, it) }
        radar.head = heading; radar.headUp = headUp; radar.range = ranges[ri]
        alertTv.text = if (mo.isEmpty()) "" else "Gerakan terdeteksi dekat ${mo[0].label()} (± ${fmt(mo[0].dist(nExp))} m)"
        if (mo.isNotEmpty() && !wasMotion && alarm) vib()
        wasMotion = mo.isNotEmpty()
        infoTv.text = "Arah ${heading.roundToInt()}°   Skala ${ranges[ri].roundToInt()} m   ${live.size} perangkat   Kompas: ${accText()}"

        when (cur) {
            1 -> if (ticks % 2 == 0) {
                listBox.removeAllViews()
                listBox.addView(tv("Perangkat (${live.size})", 20f, green))
                live.sortedBy { it.dist(nExp) }.forEach { d ->
                    val t = tv("${if (d.wifi) "WiFi" else "BT"}  ${d.label()}${if (d.vendor.isNotEmpty()) " (" + d.vendor + ")" else ""}\n${d.rssi.roundToInt()} dBm   ± ${fmt(d.dist(nExp))} m", 15f,
                        if (d.wifi) 0xFFF2C94C.toInt() else txt)
                    t.setOnClickListener { tracked = d; show(4) }
                    listBox.addView(t)
                }
            }
            2 -> calTv.text = "Akurasi: ${accText()}\nMedan magnet: ${field.roundToInt()} µT\nArah hadap: ${heading.roundToInt()}°" +
                (if (field > 0f && (field < 25f || field > 65f)) "\nPeringatan: ada gangguan magnet" else "")
            4 -> tracked?.let { d ->
                val x = d.dist(nExp)
                val dl = if (d.hist.size >= 6) d.hist.last() - d.hist[d.hist.size - 6] else 0f
                val lvl = if (x < 2) "Panas" else if (x < 5) "Hangat" else "Dingin"
                trName.text = d.label()
                trDist.text = "${fmt(x)} m"
                trHot.text = "$lvl, " + (if (dl < -0.5f) "makin dekat" else if (dl > 0.5f) "makin jauh" else "stabil")
                chart.data = ArrayList(d.hist); chart.invalidate()
                trInfo.text = "RSSI ${d.rssi.roundToInt()} dBm   RSSI 1 m ${d.tx1m.roundToInt()} dBm   n=$nExp"
                trDesc.text = info(d, d in mo)
            }
        }
    }

    override fun onSensorChanged(e: SensorEvent) {
        if (e.sensor.type == Sensor.TYPE_ROTATION_VECTOR) {
            val r = FloatArray(9)
            SensorManager.getRotationMatrixFromVector(r, e.values)
            val o = FloatArray(3)
            SensorManager.getOrientation(r, o)
            var az = o[0]
            if (abs(o[1]) > 0.8f) {
                val r2 = FloatArray(9)
                SensorManager.remapCoordinateSystem(r, SensorManager.AXIS_X, SensorManager.AXIS_Z, r2)
                SensorManager.getOrientation(r2, o)
                az = o[0]
            }
            sn = sn * 0.85 + sin(az.toDouble()) * 0.15
            cs = cs * 0.85 + cos(az.toDouble()) * 0.15
            heading = ((Math.toDegrees(atan2(sn, cs)) + 360) % 360).toFloat()
        } else if (e.sensor.type == Sensor.TYPE_MAGNETIC_FIELD) {
            field = sqrt(e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2])
        }
    }

    override fun onAccuracyChanged(s: Sensor, a: Int) {
        if (s.type == Sensor.TYPE_MAGNETIC_FIELD) acc = a
    }

    override fun onResume() {
        super.onResume()
        sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
        sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
        h.post(loop)
    }

    override fun onPause() {
        super.onPause()
        sm.unregisterListener(this)
        h.removeCallbacks(loop)
    }

    override fun onDestroy() {
        super.onDestroy()
        try { getSystemService(BluetoothManager::class.java).adapter?.bluetoothLeScanner?.stopScan(cb) } catch (e: Exception) { }
    }
}
