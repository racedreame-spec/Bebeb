package com.radar.kapal

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.*

class P(val a: Float, val d: Float, val wifi: Boolean, val mo: Boolean, val dev: Dev)

class RadarView(c: Context) : View(c) {
    var pts: List<P> = emptyList()
    var head = 0f
    var headUp = true
    var range = 20f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var sg: SweepGradient? = null
    private var sgKey = 0
    var onPick: ((Dev) -> Unit)? = null
    private val spots = ArrayList<Triple<Float, Float, Dev>>()

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_UP) {
            val s = spots.minByOrNull { hypot(it.first - e.x, it.second - e.y) }
            if (s != null && hypot(s.first - e.x, s.second - e.y) < 70f) onPick?.invoke(s.third)
        }
        return true
    }

    override fun onDraw(cv: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r0 = min(cx, cy) - 36f
        if (r0 <= 0f) return
        cv.drawColor(0xFF0A130F.toInt())
        spots.clear()
        p.style = Paint.Style.FILL; p.color = 0xFF0D1D15.toInt(); cv.drawCircle(cx, cy, r0, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = 0x663DDC84
        for (i in 1..3) cv.drawCircle(cx, cy, r0 * i / 3, p)
        cv.drawLine(cx - r0, cy, cx + r0, cy, p)
        cv.drawLine(cx, cy - r0, cx, cy + r0, p)
        val off = if (headUp) -head else 0f
        p.style = Paint.Style.FILL; p.textSize = 30f; p.textAlign = Paint.Align.CENTER; p.color = 0xFF9FE8BD.toInt()
        listOf("U", "T", "S", "B").forEachIndexed { i, s ->
            val a = Math.toRadians((i * 90 + off).toDouble())
            cv.drawText(s, cx + (r0 + 22) * sin(a).toFloat(), cy - (r0 + 22) * cos(a).toFloat() + 10, p)
        }
        p.textSize = 24f; p.textAlign = Paint.Align.LEFT
        for (i in 1..3) cv.drawText("${(range * i / 3).roundToInt()} m", cx + 8, cy - r0 * i / 3 - 6, p)

        val t = (System.currentTimeMillis() % 4000) / 4000f * 360f
        val key = width * 10000 + height
        if (sg == null || sgKey != key) {
            sg = SweepGradient(cx, cy, intArrayOf(0x003DDC84, 0x003DDC84, 0x883DDC84.toInt()), floatArrayOf(0f, 0.8f, 1f))
            sgKey = key
        }
        cv.save()
        cv.rotate(t - 90f, cx, cy)
        p.style = Paint.Style.FILL; p.shader = sg; cv.drawCircle(cx, cy, r0, p); p.shader = null
        p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = 0xFF3DDC84.toInt()
        cv.drawLine(cx, cy, cx + r0, cy, p)
        cv.restore()

        for (pt in pts) {
            val ang = pt.a + off
            val a = Math.toRadians(ang.toDouble())
            val r = min(pt.d / range, 1f) * r0
            val x = cx + r * sin(a).toFloat()
            val y = cy - r * cos(a).toFloat()
            spots.add(Triple(x, y, pt.dev))
            val ph = (((t - ang) % 360f) + 360f) % 360f
            val al = (255 * (1f - ph / 360f * 0.75f)).toInt()
            val col = if (pt.wifi) 0xF2C94C else 0x3DDC84
            p.style = Paint.Style.FILL; p.color = (al shl 24) or col
            cv.drawCircle(x, y, 11f, p)
            if (pt.mo) {
                val k = (System.currentTimeMillis() % 1600) / 1600f
                p.style = Paint.Style.STROKE; p.strokeWidth = 3f
                p.color = ((255 * (1 - k)).toInt() shl 24) or 0xFF6B6B
                cv.drawCircle(x, y, 11 + 40 * k, p)
            }
        }
        p.style = Paint.Style.FILL; p.color = 0xFF9FE8BD.toInt(); cv.drawCircle(cx, cy, 6f, p)
        postInvalidateOnAnimation()
    }
}

class ChartView(c: Context) : View(c) {
    var data: List<Float> = emptyList()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = 0x553DDC84
        cv.drawLine(20f, h - 20, w - 20, h - 20, p)
        if (data.size < 2) return
        val mx = max(data.maxOrNull() ?: 1f, 1f)
        p.color = 0xFF3DDC84.toInt(); p.strokeWidth = 4f
        for (i in 1 until data.size) {
            val x0 = 20 + (w - 40) * (i - 1) / (data.size - 1)
            val x1 = 20 + (w - 40) * i / (data.size - 1)
            val y0 = h - 20 - (h - 40) * data[i - 1] / mx
            val y1 = h - 20 - (h - 40) * data[i] / mx
            cv.drawLine(x0, y0, x1, y1, p)
        }
        p.style = Paint.Style.FILL; p.textSize = 24f; p.color = 0xFF7FBF9C.toInt()
        cv.drawText("${mx.roundToInt()} m", 24f, 28f, p)
    }
}
