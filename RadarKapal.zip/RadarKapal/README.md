# Radar Kapal
Radar Bluetooth + WiFi bergaya radar kapal. Unggah isi folder ini ke repo GitHub (branch main),
lalu buka tab Actions > Build APK > unduh artifact RadarKapal-APK (app-debug.apk).
